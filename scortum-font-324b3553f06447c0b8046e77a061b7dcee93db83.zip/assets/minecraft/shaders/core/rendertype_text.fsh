#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec4 hudRect;
in vec2 guiPos;

out vec4 fragColor;

// Ванильный rendertype_text.fsh + рамка свободного режима HUD (см. rendertype_text.vsh):
// у рамки остаётся только полоса толщиной k физ. px по краю квада.
// + блик логотипа в ESC (tools/hud/menu_esc.py): буквы помечены альфой 254, блик как в табе (TabDecor).
const float ESC_LOGO_HALF = 60.0;     // заголовок центрирован: левый край = центр - advance/2 (advance 121)
const float ESC_LOGO_TOP  = 31.0;     // y = 40, ascent 16 -> верх на 40 + 7 - 16
const float ESC_LOGO_W    = 121.0;
const float SHINE_PERIOD  = 5000.0, SHINE_MS = 1200.0;

void main() {
    if (hudRect.z > 0.0) {
        float k = max(1.0, round(ScreenSize.y / 1080.0));
        vec2 d = min(hudRect.xy, hudRect.zw - hudRect.xy);
        if (min(d.x, d.y) > k) {
            discard;
        }
    }
    vec4 tex = texture(Sampler0, texCoord0);
    vec4 color = tex * vertexColor * ColorModulator;
    if (abs(tex.a * 255.0 - 254.0) < 0.5 && guiPos.x > -50000.0) {
        color.a = vertexColor.a * ColorModulator.a;
        // GameTime: 0..1 за 24000 тиков = 1 200 000 мс (делится на период - без скачка)
        float phase = mod(GameTime * 1200000.0, SHINE_PERIOD);
        if (phase < SHINE_MS && vertexColor.r + vertexColor.g + vertexColor.b > 1.5) {   // не тень
            float shine = -20.0 + phase / SHINE_MS * (ESC_LOGO_W + 30.0);
            float d = floor(guiPos.x + ESC_LOGO_HALF) - floor(guiPos.y - ESC_LOGO_TOP) * 0.7 - shine;
            if (d >= 0.0 && d < 6.0) {
                color.rgb = mix(color.rgb, vec3(1.0), 0.8);
            }
        }
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
