#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// ============================== Scortum HUD ==============================
// Носитель - заголовок ПЕРВОГО боссбара: строка центрирована, её ширина всегда 2 px
// (x начала = центр - 1), верх заглавных букв на y = 3 GUI px.
const vec2  HUD_ORIGIN = vec2(-1.0, 3.0);
const float HUD_BIAS   = 16384.0;      // все глифы шрифта scortum:hud опущены на столько px
const bool  HUD_DEBUG  = false;         // true -> весь HUD красный (проверка, что шейдер загружен)

const vec4 HUD_PALETTE[64] = vec4[64](
    vec4(0.0000, 0.0000, 0.0000, 1.0000),
    vec4(0.0000, 0.0000, 0.6667, 1.0000),
    vec4(0.0000, 0.6667, 0.0000, 1.0000),
    vec4(0.0000, 0.6667, 0.6667, 1.0000),
    vec4(0.6667, 0.0000, 0.0000, 1.0000),
    vec4(0.6667, 0.0000, 0.6667, 1.0000),
    vec4(1.0000, 0.6667, 0.0000, 1.0000),
    vec4(0.6667, 0.6667, 0.6667, 1.0000),
    vec4(0.3333, 0.3333, 0.3333, 1.0000),
    vec4(0.3333, 0.3333, 1.0000, 1.0000),
    vec4(0.3333, 1.0000, 0.3333, 1.0000),
    vec4(0.3333, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 0.3333, 0.3333, 1.0000),
    vec4(1.0000, 0.3333, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 0.3333, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(0.1569, 0.1569, 0.1765, 0.6667),
    vec4(0.0863, 0.0863, 0.1020, 0.8431),
    vec4(0.2431, 0.2431, 0.2745, 1.0000),
    vec4(1.0000, 0.7059, 0.1569, 1.0000),
    vec4(0.2353, 0.0549, 0.0706, 0.8431),
    vec4(0.9020, 0.2353, 0.2353, 1.0000),
    vec4(0.3529, 0.8627, 0.4314, 1.0000),
    vec4(1.0000, 0.7059, 0.1569, 1.0000),
    vec4(0.2275, 0.1804, 0.0941, 0.8824),
    vec4(0.0941, 0.0941, 0.1098, 0.7843),
    vec4(0.3333, 1.0000, 0.4706, 1.0000),
    vec4(0.2471, 0.2471, 0.2471, 1.0000),
    vec4(1.0000, 0.0000, 0.0000, 1.0000),
    vec4(1.0000, 0.1804, 0.1804, 1.0000),
    vec4(0.0118, 0.5176, 0.9882, 1.0000),
    vec4(0.0000, 0.8980, 1.0000, 1.0000),
    vec4(0.2157, 0.9255, 0.0275, 1.0000),
    vec4(0.0863, 0.2353, 0.0784, 0.8824),
    vec4(0.2353, 0.9412, 0.1569, 1.0000),
    vec4(0.2745, 0.1961, 0.0392, 0.8824),
    vec4(1.0000, 0.7843, 0.1176, 1.0000),
    vec4(0.2745, 0.0706, 0.0471, 0.8824),
    vec4(1.0000, 0.4314, 0.0784, 1.0000),
    vec4(0.2745, 0.3922, 1.0000, 1.0000),
    vec4(1.0000, 0.2745, 0.2745, 1.0000),
    vec4(0.0980, 0.1373, 0.3529, 0.8431),
    vec4(0.3529, 0.0863, 0.0863, 0.8431),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000)
);

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;

    // GUI рисуется в ортографической проекции (ProjMat[3][3] == 1), мир - в перспективе (0).
    if (ProjMat[3][3] != 0.0) {
        vec2 px = vec2(ProjMat[0][0], ProjMat[1][1]);                    // клип-единиц на 1 GUI px (y < 0)
        vec2 gui = vec2((gl_Position.x / gl_Position.w + 1.0) / px.x,     // позиция вершины в GUI px
                        (gl_Position.y / gl_Position.w - 1.0) / px.y);
        if (gui.y > HUD_BIAS * 0.5) {                                     // глиф шрифта scortum:hud
            ivec3 c = ivec3(round(Color.rgb * 255.0));
            int v = (c.r << 16) | (c.g << 8) | c.b;
            float dy = float(((v >> 14) & 1023) - 512);
            int pal  = (v >> 8) & 63;
            int col  = (v >> 6) & 3;
            int row  = (v >> 4) & 3;

            vec2 guiSize = vec2(round(2.0 / px.x), round(-2.0 / px.y));
            // Начало строки боссбара: x = guiW/2 (целочисленно) + HUD_ORIGIN.x, y = HUD_ORIGIN.y + BIAS.
            vec2 origin = vec2(floor(guiSize.x * 0.5) + HUD_ORIGIN.x, HUD_ORIGIN.y + HUD_BIAS);
            // round(): убирает погрешность float от огромного BIAS - иначе между кусками фона бывают щели в 1 px.
            vec2 local  = round(gui - origin);
            vec2 anchor = floor(vec2(float(col), float(row)) * 0.5 * guiSize);
            vec2 p = anchor + local + vec2(0.0, dy);
            gl_Position.xy = vec2(p.x * px.x - 1.0, 1.0 + p.y * px.y) * gl_Position.w;

            vertexColor = HUD_PALETTE[pal] * vec4(1.0, 1.0, 1.0, Color.a);
            if (HUD_DEBUG) vertexColor = vec4(1.0, 0.0, 0.0, 1.0);
        }
    }
}
