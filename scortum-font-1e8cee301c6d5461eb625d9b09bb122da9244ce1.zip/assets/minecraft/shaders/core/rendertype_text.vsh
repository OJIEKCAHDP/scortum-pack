#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec4 hudRect;       // свободный режим, рамка: xy - позиция внутри, zw - размер (физ. px); z == 0 - не рамка

// ============================== Scortum HUD ==============================
// Носитель - заголовок ПЕРВОГО боссбара: строка центрирована, её ширина всегда 2 px
// (x начала = центр - 1), верх заглавных букв на y = 3 GUI px.
const vec2  HUD_ORIGIN = vec2(-1.0, 3.0);
const float HUD_BIAS   = 16384.0;      // все глифы шрифта scortum:hud опущены на столько px
const bool  HUD_DEBUG  = false;         // true -> весь HUD красный (проверка, что шейдер загружен)

const vec4 HUD_PALETTE[64] = vec4[64](
    vec4(0.0000, 0.0000, 0.0000, 1.0000),
    vec4(0.0000, 0.0000, 0.6667, 1.0000),
    vec4(0.0000, 0.6667, 0.0000, 1.0000),
    vec4(0.0000, 0.6667, 0.6667, 1.0000),
    vec4(0.6667, 0.0000, 0.0000, 1.0000),
    vec4(0.6667, 0.0000, 0.6667, 1.0000),
    vec4(1.0000, 0.6667, 0.0000, 1.0000),
    vec4(0.6667, 0.6667, 0.6667, 1.0000),
    vec4(0.3333, 0.3333, 0.3333, 1.0000),
    vec4(0.3333, 0.3333, 1.0000, 1.0000),
    vec4(0.3333, 1.0000, 0.3333, 1.0000),
    vec4(0.3333, 1.0000, 1.0000, 1.0000),
    vec4(1.0000, 0.3333, 0.3333, 1.0000),
    vec4(1.0000, 0.3333, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 0.3333, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(0.1569, 0.1569, 0.1765, 0.6667),
    vec4(0.0863, 0.0863, 0.1020, 0.8431),
    vec4(0.2431, 0.2431, 0.2745, 1.0000),
    vec4(1.0000, 0.7059, 0.1569, 1.0000),
    vec4(0.2353, 0.0549, 0.0706, 0.8431),
    vec4(0.9020, 0.2353, 0.2353, 1.0000),
    vec4(0.3529, 0.8627, 0.4314, 1.0000),
    vec4(1.0000, 0.7059, 0.1569, 1.0000),
    vec4(0.2275, 0.1804, 0.0941, 0.8824),
    vec4(0.0941, 0.0941, 0.1098, 0.7843),
    vec4(0.3333, 1.0000, 0.4706, 1.0000),
    vec4(0.2471, 0.2471, 0.2471, 1.0000),
    vec4(1.0000, 0.0000, 0.0000, 1.0000),
    vec4(1.0000, 0.1804, 0.1804, 1.0000),
    vec4(0.0118, 0.5176, 0.9882, 1.0000),
    vec4(0.0000, 0.8980, 1.0000, 1.0000),
    vec4(0.2157, 0.9255, 0.0275, 1.0000),
    vec4(0.0863, 0.2353, 0.0784, 0.8824),
    vec4(0.2353, 0.9412, 0.1569, 1.0000),
    vec4(0.2745, 0.1961, 0.0392, 0.8824),
    vec4(1.0000, 0.7843, 0.1176, 1.0000),
    vec4(0.2745, 0.0706, 0.0471, 0.8824),
    vec4(1.0000, 0.4314, 0.0784, 1.0000),
    vec4(0.2745, 0.3922, 1.0000, 1.0000),
    vec4(1.0000, 0.2745, 0.2745, 1.0000),
    vec4(0.0980, 0.1373, 0.3529, 0.8431),
    vec4(0.3529, 0.0863, 0.0863, 0.8431),
    vec4(0.1333, 0.2275, 0.1843, 0.8824),
    vec4(0.4824, 0.7882, 0.6510, 1.0000),
    vec4(0.9098, 0.6275, 0.3608, 1.0000),
    vec4(0.9098, 0.8863, 0.8392, 1.0000),
    vec4(0.8784, 0.4784, 0.4196, 1.0000),
    vec4(0.7882, 0.6275, 0.8627, 1.0000),
    vec4(0.5451, 0.5843, 0.6471, 1.0000),
    vec4(0.1255, 0.0863, 0.2039, 0.8431),
    vec4(0.3059, 0.0941, 0.0863, 0.8627),
    vec4(0.9412, 0.7843, 0.3529, 1.0000),
    vec4(0.1882, 0.1255, 0.3059, 0.8824),
    vec4(0.8039, 0.6667, 0.9412, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 0.1765),
    vec4(0.3059, 0.2196, 0.0627, 0.8824),
    vec4(0.7059, 0.4706, 1.0000, 1.0000),
    vec4(0.1098, 0.1176, 0.1490, 0.8431),
    vec4(0.2745, 0.3294, 0.4706, 0.9216),
    vec4(0.0784, 0.0784, 0.0941, 0.6667),
    vec4(0.0000, 0.0000, 0.0000, 0.5882),
    vec4(0.3529, 0.5882, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000)
);

// ---- свободный режим (см. FREE_* в build_pack.py и HudCanvas.free*)
const int  FREE_SLOTS  = 8;
const int  FREE_BD     = 16;
const int  FREE_ICON_B = 257;
const vec4 FREE_PALETTE[8] = vec4[8](
    vec4(0.3529, 0.6667, 1.0000, 0.2196),
    vec4(0.4706, 0.7647, 1.0000, 1.0000),
    vec4(1.0000, 1.0000, 1.0000, 1.0000),
    vec4(0.0000, 0.0000, 0.0000, 0.7843),
    vec4(0.3529, 0.8627, 0.4314, 1.0000),
    vec4(0.9020, 0.2353, 0.2353, 1.0000),
    vec4(1.0000, 0.3529, 0.3529, 1.0000),
    vec4(0.3529, 0.6667, 1.0000, 1.0000)
);

// Координаты свободного режима - в половинах высоты экрана от центра (y вниз).
float free_x(int x) { return float(x) / 2047.0 * 6.0 - 3.0; }   // 11 бит, -3..3
float free_y(int y) { return float(y) / 1023.0 * 2.0 - 1.0; }   // 10 бит, -1..1

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
    hudRect = vec4(0.0);

    // GUI рисуется в ортографической проекции (ProjMat[3][3] == 1), мир - в перспективе (0).
    if (ProjMat[3][3] != 0.0) {
        vec2 px = vec2(ProjMat[0][0], ProjMat[1][1]);                    // клип-единиц на 1 GUI px (y < 0)
        vec2 gui = vec2((gl_Position.x / gl_Position.w + 1.0) / px.x,     // позиция вершины в GUI px
                        (gl_Position.y / gl_Position.w - 1.0) / px.y);
        if (gui.y > HUD_BIAS * 0.5) {                                     // глиф шрифта scortum:hud
            ivec3 c = ivec3(round(Color.rgb * 255.0));
            int v = (c.r << 16) | (c.g << 8) | c.b;
            float dy = float(((v >> 14) & 1023) - 512);
            int pal  = (v >> 8) & 63;
            int col  = (v >> 6) & 3;
            int row  = (v >> 4) & 3;

            vec2 guiSize = vec2(round(2.0 / px.x), round(-2.0 / px.y));
            // Начало строки боссбара: x = guiW/2 (целочисленно) + HUD_ORIGIN.x, y = HUD_ORIGIN.y + BIAS.
            vec2 origin = vec2(floor(guiSize.x * 0.5) + HUD_ORIGIN.x, HUD_ORIGIN.y + HUD_BIAS);
            // round(): убирает погрешность float от огромного BIAS - иначе между кусками фона бывают щели в 1 px.
            vec2 local  = round(gui - origin);

            if (local.y >= 128.0 && local.y < 256.0) {
                // ---------- голова скина: цвет текста - сам цвет пикселя; от левого верхнего угла ----------
                vec2 p = vec2(local.x, local.y - 128.0);
                gl_Position.xy = vec2(p.x * px.x - 1.0, 1.0 + p.y * px.y) * gl_Position.w;
                vertexColor = vec4(Color.rgb, Color.a);
            } else if (local.y >= 256.0) {
                // ---------- свободный режим: глиф стоит на (512*L, 512*B), квад 256 px ----------
                float fb = floor(local.y / 512.0);
                float fl = floor(local.x / 512.0);
                vec2 corner = vec2(local.x - fl * 512.0 > 16.0 ? 1.0 : 0.0,       // какой это угол квада
                                   local.y - fb * 512.0 > 128.0 ? 1.0 : 0.0);
                int B = int(fb);
                int L = int(fl);
                float unit = guiSize.y * 0.5;                        // половина высоты экрана, GUI px
                vec2 center = guiSize * 0.5;
                float phys = ScreenSize.y / guiSize.y;               // физических px на GUI px
                float k = max(1.0, round(ScreenSize.y / 1080.0));    // 1 при 1080p, 2 при 4K
                vec2 p;
                if (B < FREE_ICON_B) {
                    // заливка / рамка: 42 бита = x1, x2 (11), y1, y2 (10): цвет 24 + L 14 + младшие 4 бита B
                    int kind = (B - 1) / (FREE_SLOTS * FREE_BD);
                    int slot = ((B - 1) / FREE_BD) % FREE_SLOTS;
                    int bd   = (B - 1) % FREE_BD;
                    int x1 = v & 2047;
                    int x2 = (v >> 11) & 2047;
                    int y1 = ((v >> 22) & 3) | ((L & 255) << 2);
                    int y2 = ((L >> 8) & 63) | (bd << 6);
                    vec2 a = round((center + vec2(free_x(x1), free_y(y1)) * unit) * phys) / phys;
                    vec2 b = round((center + vec2(free_x(x2), free_y(y2)) * unit) * phys) / phys;
                    vec2 lo = min(a, b);
                    vec2 hi = max(a, b);
                    p = mix(lo, hi, corner);
                    vertexColor = FREE_PALETTE[slot];
                    if (kind == 1) hudRect = vec4(corner * (hi - lo) * phys, max((hi - lo) * phys, vec2(0.001)));
                } else {
                    // иконка: x (11 бит), y (10 бит), центрировать (1 бит); размер в px при 1080p - в L
                    int x = v & 2047;
                    int y = (v >> 11) & 1023;
                    bool centered = ((v >> 21) & 1) == 1;
                    vec2 size = vec2(float(L & 127), float((L >> 7) & 127)) * k / phys;
                    vec2 at = round((center + vec2(free_x(x), free_y(y)) * unit) * phys) / phys;
                    p = at + (corner - (centered ? 0.5 : 0.0)) * size;
                    vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
                }
                gl_Position.xy = vec2(p.x * px.x - 1.0, 1.0 + p.y * px.y) * gl_Position.w;
            } else {
                vec2 anchor = floor(vec2(float(col), float(row)) * 0.5 * guiSize);
                vec2 p = anchor + local + vec2(0.0, dy);
                gl_Position.xy = vec2(p.x * px.x - 1.0, 1.0 + p.y * px.y) * gl_Position.w;

                vertexColor = HUD_PALETTE[pal] * vec4(1.0, 1.0, 1.0, Color.a);
            }
            if (HUD_DEBUG) vertexColor = vec4(1.0, 0.0, 0.0, 1.0);
        }
    }
}
