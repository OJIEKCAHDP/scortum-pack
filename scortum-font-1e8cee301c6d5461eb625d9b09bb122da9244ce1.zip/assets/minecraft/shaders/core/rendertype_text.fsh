#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec4 hudRect;

out vec4 fragColor;

// Ванильный rendertype_text.fsh + рамка свободного режима HUD (см. rendertype_text.vsh):
// у рамки остаётся только полоса толщиной k физ. px по краю квада.
void main() {
    if (hudRect.z > 0.0) {
        float k = max(1.0, round(ScreenSize.y / 1080.0));
        vec2 d = min(hudRect.xy, hudRect.zw - hudRect.xy);
        if (min(d.x, d.y) > k) {
            discard;
        }
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
