// Overlord: курсор и рамка выделения на клиенте - без пинга.
//
// Игрок сидит на невидимой управляемой свинье (TopDownSession: probePig). Такую свинью клиент поворачивает сам:
// yaw = yaw игрока, наклон головы = pitch игрока * 0.5. Седло свиньи - наш ассет overlord:cursor*
// (textures/entity/equipment/pig_saddle/cursor*.png, 1024x1024 = модель 64x64 в 16 раз крупнее):
//   * texel (0,0) = #FE01FD, (1,0) = #01FE02 - по ним шейдер узнаёт седло-зонд;
//   * передняя грань головы (UV 8..16 x 8..16) - спрайт курсора, горячая точка в центре грани;
//   * задняя грань (UV 24..32 x 8..16) - рамка выделения; её начало сервер кладёт в цвет седла (dyed_color):
//     u - 12 бит (r, старшие 4 бита g), v - 12 бит (младшие 4 бита g, b); 0xFFF/0xFFF - рамки нет.
// Курсор по формуле сервера (TopDownSession.applyRotation): u = yaw/90, v = pitch/90 - в половинах высоты
// экрана от центра, v вниз.

const vec2 PROBE_FRONT_MIN = vec2(8.0, 8.0) / 64.0;
const vec2 PROBE_FRONT_MAX = vec2(16.0, 16.0) / 64.0;
const vec2 PROBE_BACK_MIN = vec2(24.0, 8.0) / 64.0;
const vec2 PROBE_BACK_MAX = vec2(32.0, 16.0) / 64.0;
const float PROBE_EPS = 0.25 / 64.0;
const float PROBE_PITCH_SCALE = 2.0;    // голова свиньи наклоняется на половину pitch игрока
const float PROBE_CURSOR_PX = 64.0;     // сторона грани-курсора в пикселях иконки (1 px при 1080p)

bool probe_near(vec4 c, vec3 rgb) {
    return c.a > 0.99 && all(lessThan(abs(c.rgb * 255.0 - rgb), vec3(0.6)));
}

bool probe_texture(sampler2D s) {
    return probe_near(texelFetch(s, ivec2(0, 0), 0), vec3(254.0, 1.0, 253.0))
        && probe_near(texelFetch(s, ivec2(1, 0), 0), vec3(1.0, 254.0, 2.0));
}

bool probe_in(vec2 uv, vec2 lo, vec2 hi) {
    return all(greaterThanEqual(uv, lo - PROBE_EPS)) && all(lessThanEqual(uv, hi + PROBE_EPS));
}

/** Пиксель иконки в пикселях экрана: 1 при 1080p, 2 при 4K (как в HUD). */
float probe_pixel(vec2 screen) {
    return max(1.0, floor(screen.y / 1080.0 + 0.5));
}

/** Курсор (u, v) по направлению "вперёд" головы свиньи. */
vec2 probe_cursor(vec3 forward, float aspect) {
    vec3 f = normalize(forward);
    float yaw = degrees(atan(-f.x, f.z));                                     // 0 = +Z, как в Minecraft
    float pitch = degrees(asin(clamp(-f.y, -1.0, 1.0))) * PROBE_PITCH_SCALE;  // вниз - плюс
    return vec2(clamp(yaw / 90.0, -aspect, aspect), clamp(pitch / 90.0, -1.0, 1.0));
}

/** Строго внутри области (для фрагментов: соседние грани касаются её края). */
bool probe_inside(vec2 uv, vec2 lo, vec2 hi) {
    return all(greaterThan(uv, lo + PROBE_EPS * 0.04)) && all(lessThan(uv, hi - PROBE_EPS * 0.04));
}

vec2 probe_ndc(vec2 uv, float aspect) {
    return vec2(uv.x / aspect, -uv.y);
}
