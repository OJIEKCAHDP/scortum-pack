#version 330

// Overlord: vanilla 26.1 entity.fsh + рамка выделения на клиенте (include/overlord_probe.glsl).

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:overlord_probe.glsl>

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif

#ifndef EMISSIVE
in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    // Overlord: задняя грань седла-зонда - рамка выделения (контур толщиной в пиксель иконки).
    if (probe_inside(texCoord0, PROBE_BACK_MIN, PROBE_BACK_MAX) && probe_texture(Sampler0)) {
        vec2 t = (texCoord0 - PROBE_BACK_MIN) / (PROBE_BACK_MAX - PROBE_BACK_MIN);
        vec2 edge = min(t, 1.0 - t) / max(fwidth(t), vec2(1e-6));   // до края рамки, в пикселях экрана
        if (min(edge.x, edge.y) >= probe_pixel(ScreenSize)) {
            discard;
        }
        fragColor = vec4(120.0, 195.0, 255.0, 255.0) / 255.0;
        return;
    }
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
