#version 330
// Overlord: vanilla 26.3 entity.vsh + курсор/рамка на клиенте (include/overlord_probe.glsl).
#extension GL_ARB_separate_shader_objects : require

#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#include <minecraft:light.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:overlord_probe.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
layout(location = 5) in vec3 Normal;

uniform sampler2D Sampler0;

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler1;
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
layout(location = 2) out vec4 vertexPerFaceColorBack;
layout(location = 3) out vec4 vertexPerFaceColorFront;
#else
layout(location = 2) out vec4 vertexColor;
#endif

#ifndef EMISSIVE
layout(location = 4) out vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
layout(location = 5) out vec4 overlayColor;
#endif

layout(location = 6) out vec2 texCoord0;
#ifdef GLINT
layout(location = 7) out vec2 texCoordGlint;
#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

#ifdef PER_FACE_LIGHTING
    vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
    vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
    vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
    vertexColor = Color;
#else
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif

#if !defined(EMISSIVE) && !defined(OIT_ALPHA_ONLY)
    lightMapColor = sample_lightmap(Sampler2, UV2);
#endif

#if !defined(NO_OVERLAY) && !defined(OIT_ALPHA_ONLY)
    overlayColor = texelFetch(Sampler1, UV1, 0);
#endif

    texCoord0 = UV0;

#ifdef APPLY_TEXTURE_MATRIX
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

#ifdef GLINT
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif

    // Overlord: седло-зонд - переносим грани в экранные координаты, без освещения.
    if (probe_texture(Sampler0)) {
        float aspect = ScreenSize.x / max(ScreenSize.y, 1.0);
        vec2 ndc = vec2(-2.0);                                // лишние грани - в точку за экраном
        if (probe_in(UV0, PROBE_FRONT_MIN, PROBE_FRONT_MAX)) {
            // Курсор: центр грани - в точке курсора; угол вершины - по её UV (верх текстуры = верх экрана).
            vec2 center = (PROBE_FRONT_MIN + PROBE_FRONT_MAX) * 0.5;
            vec2 corner = vec2(UV0.x < center.x ? -1.0 : 1.0, UV0.y < center.y ? 1.0 : -1.0);
            float halfPx = PROBE_CURSOR_PX * 0.5 * probe_pixel(ScreenSize);
            ndc = probe_ndc(probe_cursor(Normal, aspect), aspect) + corner * halfPx * 2.0 / ScreenSize;
        } else if (probe_in(UV0, PROBE_BACK_MIN, PROBE_BACK_MAX)) {
            // Рамка: от точки начала (цвет седла) до курсора (задняя грань смотрит назад -> минус нормаль).
            vec3 c = floor(Color.rgb * 255.0 + 0.5);
            float su = c.r * 16.0 + floor(c.g / 16.0);
            float sv = mod(c.g, 16.0) * 256.0 + c.b;
            if (su < 4095.0 || sv < 4095.0) {
                vec2 start = vec2(su / 4094.0 * 8.0 - 4.0, sv / 4094.0 * 2.0 - 1.0);
                vec2 live = probe_cursor(-Normal, aspect);
                vec2 lo = min(start, live), hi = max(start, live);
                vec2 center = (PROBE_BACK_MIN + PROBE_BACK_MAX) * 0.5;
                vec2 p = vec2(UV0.x < center.x ? lo.x : hi.x, UV0.y < center.y ? lo.y : hi.y);
                ndc = probe_ndc(p, aspect);
            }
        }
        gl_Position = vec4(ndc, 0.999, 1.0);     // 26.2+: буфер глубины обратный, ближняя плоскость - у +1
#ifdef PER_FACE_LIGHTING
        vertexPerFaceColorBack = vec4(1.0);
        vertexPerFaceColorFront = vec4(1.0);
#else
        vertexColor = vec4(1.0);
#endif
#ifndef EMISSIVE
        lightMapColor = vec4(1.0);
#endif
#ifndef NO_OVERLAY
        overlayColor = vec4(1.0);
#endif
        sphericalVertexDistance = 0.0;
        cylindricalVertexDistance = 0.0;
    }
}
