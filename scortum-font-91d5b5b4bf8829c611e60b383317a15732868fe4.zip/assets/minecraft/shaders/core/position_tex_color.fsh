#version 330

// Overlord: vanilla 26.1 position_tex_color.fsh + hiding marked HUD sprites (alpha 254) in top-down mode.
// Globals is a built-in uniform (GlProgram.BUILT_IN_UNIFORMS); declared inline because this shader is used at startup.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    vec3 CameraOffset;
    vec2 ScreenSize;
    float GlintAlpha;
    float GameTime;
    int MenuBlurRadius;
    int UseRgss;
};

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    if (abs(tex.a * 255.0 - 254.0) < 0.5) {
        if (CameraBlockPos.x > 900000) {
            discard;
        }
        tex.a = 1.0;
    }
    vec4 color = tex * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
